"use client"

import type * as React from "react"
import { Home, CheckSquare, FileText, User, LogOut, Activity } from "lucide-react"
import Image from "next/image"
import { useEffect, useState } from "react"
import { usePathname, useRouter } from "next/navigation"

import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
} from "@/components/ui/sidebar"
import { useSidebar } from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { PanelRightClose } from "lucide-react"
import { useIsMobile } from "@/hooks/use-mobile"

// Elementos del menú para maestros
const menuItems = [
  {
    title: "Inicio",
    icon: Home,
    url: "/maestros",
  },
  {
    title: "Calificar",
    icon: CheckSquare,
    url: "/maestros/calificar",
  },
  {
    title: "Actividades",
    icon: Activity,
    url: "/maestros/actividades",
  },
  {
    title: "Informes",
    icon: FileText,
    url: "/maestros/reportes",
  },
  {
    title: "Cuenta",
    icon: User,
    url: "/maestros/cuenta",
  },
  {
    title: "Cierre de sesión",
    icon: LogOut,
    url: "/logout",
  },
]

export function AppSidebarTeacher({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const { toggleSidebar } = useSidebar()
  const isMobile = useIsMobile()
  const [mounted, setMounted] = useState(false)
  const pathname = usePathname()
  const router = useRouter()
  const [teacherName, setTeacherName] = useState("Dr. Juan Pérez")
  const [teacherInitials, setTeacherInitials] = useState("DJP")

  useEffect(() => {
    setMounted(true)

    // Obtener nombre del maestro del localStorage
    const storedName = localStorage.getItem("username")
    if (storedName) {
      setTeacherName(storedName)
      // Generar iniciales
      setTeacherInitials(
        storedName
          .split(" ")
          .map((name) => name[0])
          .join(""),
      )
    }
  }, [])

  const handleLogout = () => {
    // Limpiar localStorage
    localStorage.removeItem("isAuthenticated")
    localStorage.removeItem("username")
    localStorage.removeItem("userRole")

    // Redirigir al login
    router.push("/login")
  }

  if (!mounted) return null

  return (
    <Sidebar
      {...props}
      collapsible="offcanvas"
      className="border-r border-[#70aad8] transition-all duration-300 ease-in-out"
    >
      <SidebarHeader className="border-b border-[#70aad8]">
        <div className="flex items-center justify-between p-3">
          <div className="flex items-center gap-2">
            <div className="relative w-10 h-10 animate-pulse-slow">
              <Image src="/images/logo.png" alt="SIGAE Logo" fill className="object-contain" />
            </div>
            <div>
              <h1 className="font-bold text-[#0045aa] text-lg">SIGAE</h1>
              <p className="text-xs text-[#0f6fbd]">Softedu</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleSidebar}
            className="text-[#0045aa] hover:bg-[#70aad8]/20 transition-all duration-300"
            aria-label="Toggle sidebar"
          >
            <PanelRightClose className="h-5 w-5" />
          </Button>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu className={isMobile ? "" : "stagger-animation"}>
          {menuItems.map((item) => (
            <SidebarMenuItem key={item.title}>
              <SidebarMenuButton
                asChild
                isActive={pathname.startsWith(item.url) && item.url !== "/" ? true : pathname === item.url}
                className="text-[#0045aa] hover:bg-[#70aad8]/20 data-[active=true]:bg-[#70aad8]/30 transition-all duration-200 hover:translate-x-1"
                onClick={item.url === "/logout" ? handleLogout : undefined}
              >
                <a href={item.url === "/logout" ? "#" : item.url}>
                  <item.icon className="text-[#0f6fbd] transition-transform duration-300 ease-in-out group-hover:scale-110" />
                  <span>{item.title}</span>
                </a>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <div className="mt-auto p-4 border-t border-[#70aad8] transition-all duration-300">
        <div className="flex items-center gap-2 hover-scale">
          <div className="w-10 h-10 rounded-full bg-[#0045aa] flex items-center justify-center text-white transition-colors duration-300 hover:bg-[#0f6fbd]">
            <span>{teacherInitials}</span>
          </div>
          <div>
            <p className="text-sm font-medium text-[#0045aa]">{teacherName}</p>
            <p className="text-xs text-[#70aad8]">Maestro</p>
          </div>
        </div>
      </div>
      <SidebarRail className="transition-opacity duration-300 hover:opacity-100 opacity-50" />
    </Sidebar>
  )
}
